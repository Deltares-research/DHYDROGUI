# import os  # file exists
# import sys  # system
# import array
from datetime import datetime
# from datetime import date, timedelta
import numpy as np
import netCDF4


def main(ncfile):
    ncfile.createDimension("nNetworkBranches", 3)
    ncfile.createDimension("nNetworkNodes", 4)
    ncfile.createDimension("nGeometryNodes", 46)  # each branch includes two end nodes

    edges_1d = 12
    nodes_1d = 13
    ncfile.createDimension("nMesh1DNodes", nodes_1d)
    ncfile.createDimension("nMesh1DEdges", edges_1d)

    edges_2d = 53
    faces_2d = 26
    nodes_2d = 28
    ncfile.createDimension("max_nMesh2D_face_nodes", 4)
    ncfile.createDimension("nMesh2D_edge", edges_2d)
    ncfile.createDimension("nMesh2D_face", faces_2d)
    ncfile.createDimension("nMesh2D_node", nodes_2d)

    links_1d2d = 10
    ncfile.createDimension("nlinks_1d2d", links_1d2d)

    ncfile.createDimension("time", None)
    ncfile.createDimension("Two", 2)
    #
    # 1D Network
    #
    ntw = ncfile.createVariable("network1D", "u4", ())
    ntw.cf_role = 'mesh_topology'
    ntw.edge_dimension = 'nNetworkBranches'
    ntw.edge_geometry = 'network1D_geometry'
    ntw.edge_node_connectivity = 'network1D_edge_nodes'
    ntw.long_name = "Network topology"
    ntw.node_coordinates = 'network1D_nodes_x network1D_nodes_y'
    ntw.node_dimension = 'nNetworkNodes'
    ntw.topology_dimension = 1

    ntw_nodes_x = ncfile.createVariable("network1D_nodes_x", "f8", "nNetworkNodes")
    ntw_nodes_x.standard_name = 'projection_x_coordinate'
    ntw_nodes_x.long_name = "x coordinates of the network connection nodes"
    ntw_nodes_x.units = 'm'
    ntw_nodes_y = ncfile.createVariable("network1D_nodes_y", "f8", "nNetworkNodes")
    ntw_nodes_y.standard_name = 'projection_y_coordinate'
    ntw_nodes_y.long_name = "y coordinates of the network connection nodes"
    ntw_nodes_y.units = 'm'
    ntw_nodes_x[:] = [-187.96667, 2195.7333, 4071.4928, 3445.4246]
    ntw_nodes_y[:] = [720.81667, 708.71667, 690.94861, 1540.1838]

    ntw_geom = ncfile.createVariable("network1D_geometry", "u4", ())
    ntw_geom.geometry_type = 'multiline'
    ntw_geom.long_name = "1D Geometry"
    ntw_geom.node_count = "nGeometryNodes"
    ntw_geom.part_node_count = 'network1D_part_node_count'
    ntw_geom.node_coordinates = 'network1D_geom_x network1D_geom_y'
    
    ntw_edge_node = ncfile.createVariable("network1D_edge_nodes", "u4", ("nNetworkBranches", "Two"))
    ntw_edge_node.cf_role = 'edge_node_connectivity'
    ntw_edge_node.long_name = 'start and end nodes of each branch in the network'
    ntw_edge_node.start_index = 1
    ntw_edge_node[0, :] = [1, 2]
    ntw_edge_node[1, :] = [2, 3]
    ntw_edge_node[2, :] = [2, 4]

    ntw_geom_pnc = ncfile.createVariable("network1D_part_node_count", "u4", "nNetworkBranches")
    ntw_geom_pnc.long_name = "number of geometry nodes per branch"
    ntw_geom_pnc[:] = [22, 13, 11]  # 22+13+11=46

    ntw_geom_x = ncfile.createVariable("network1D_geom_x", "f8", "nGeometryNodes")
    ntw_geom_x.cf_role = "geometry_x_node"
    ntw_geom_x.standard_name = 'projection_x_coordinate'
    ntw_geom_x.long_name = 'x coordinates of the branch geometries'
    ntw_geom_x.units = 'm'
    ntw_geom_y = ncfile.createVariable("network1D_geom_y", "f8", "nGeometryNodes")
    ntw_geom_y.cf_role = "geometry_y_node"
    ntw_geom_y.standard_name = 'projection_y_coordinate'
    ntw_geom_y.long_name = 'y coordinates of the branch geometries'
    ntw_geom_y.units = 'm'
    ntw_geom_x[:] = [-1.8796667E+02,
                 -1.2796887E+02,
                 -5.3847860E+01,
                  5.6174104E+01,
                  1.8713333E+02,
                  3.5250000E+02,
                  5.2996667E+02,
                  6.8323333E+02,
                  8.2843333E+02,
                  8.9296667E+02,
                  9.9380000E+02,
                  1.0825333E+03,
                  1.2196667E+03,
                  1.4052000E+03,
                  1.4922591E+03,
                  1.5985306E+03,
                  1.7122164E+03,
                  1.8184835E+03,
                  1.9123747E+03,
                  2.0079644E+03,
                  2.0949000E+03,
                  2.1957333E+03,
                 #
                  2.1957333E+03,
                  2.2692456E+03,
                  2.3815612E+03,
                  2.4602412E+03,
                  2.5778276E+03,
                  2.7748643E+03,
                  2.9115187E+03,
                  3.0291051E+03,
                  3.2356759E+03,
                  3.4387319E+03,
                  3.5820791E+03,
                  3.8172519E+03,
                  4.0714928E+03,
                 #
                  2.1957333E+03,
                  2.2759165E+03,
                  2.3776129E+03,
                  2.5396914E+03,
                  2.7399061E+03,
                  2.9019847E+03,
                  3.0418172E+03,
                  3.1403355E+03,
                  3.2264949E+03,
                  3.3218353E+03,
                  3.4454246E+03]
    ntw_geom_y[:] = [7.2081667E+02,
                  8.0267261E+02,
                  8.7996131E+02,
                  9.6825292E+02,
                  1.0394500E+03,
                  1.0797833E+03,
                  1.0636500E+03,
                  9.9508333E+02,
                  8.6198333E+02,
                  7.7325000E+02,
                  6.5225000E+02,
                  5.3931667E+02,
                  4.0621667E+02,
                  2.9328333E+02,
                  2.6590693E+02,
                  2.6014026E+02,
                  2.7332123E+02,
                  3.0164228E+02,
                  3.4382527E+02,
                  4.2737378E+02,
                  5.4738333E+02,
                  7.0871667E+02,
                 #
                  7.0871667E+02,
                  7.0599709E+02,
                  6.7604627E+02,
                  6.3374441E+02,
                  5.6700618E+02,
                  5.1933601E+02,
                  5.0662397E+02,
                  5.2251403E+02,
                  5.7654021E+02,
                  6.5598306E+02,
                  6.8459259E+02,
                  6.9094861E+02,
                  6.9094861E+02,
                 #
                  7.0871667E+02,
                  8.0217900E+02,
                  8.6256121E+02,
                  9.0069734E+02,
                  9.3883347E+02,
                  1.0055717E+03,
                  1.1168021E+03,
                  1.2375665E+03,
                  1.3671587E+03,
                  1.4801547E+03,
                  1.5401838E+03]

    # 1D Mesh

    mesh1d = ncfile.createVariable("mesh1D", "u4", ())
    mesh1d.cf_role = 'mesh_topology'
    mesh1d.coordinate_space = 'network1D'
    mesh1d.edge_dimension = 'nmesh1DEdges'
    mesh1d.edge_node_connectivity = 'mesh1D_edge_nodes'
    mesh1d.long_name = "Mesh 1D"
    mesh1d.node_coordinates = 'mesh1D_nodes_branch_id mesh1D_nodes_branch_offset'
    mesh1d.node_dimension = 'nmesh1DNodes'
    mesh1d.topology_dimension = 1

    mesh1d_branch_id = ncfile.createVariable("mesh1D_nodes_branch_id", "u4", "nMesh1DNodes")
    mesh1d_branch_id.cf_role = 'feature_index'
    mesh1d_branch_id.long_name = 'number of branch on which node is located'
    mesh1d_branch_id[:] = [1, 1, 1, 1, 1, 1, 3, 3, 3, 2, 2, 2, 2]

    mesh1d_geom_offset = ncfile.createVariable("mesh1D_nodes_branch_offset", "f8", "nMesh1DNodes")
    mesh1d_geom_offset.cf_role = 'coordinate_on_feature'
    mesh1d_geom_offset.long_name = 'offset along the branch at which the node is located'
    mesh1d_geom_offset.units = 'm'
    mesh1d_geom_offset[:] = [0, 500, 1000, 1500, 2000, 2500, 700, 1400, 2100, 400, 800, 1200, 1600]

    # 2D Mesh
    
    mesh2d = ncfile.createVariable("Mesh2D", "u4", ())
    mesh2d.cf_role = 'mesh_topology'
    mesh2d.edge_coordinates = 'Mesh2D_edge_x Mesh2D_edge_y'
    mesh2d.edge_dimension = 'nMesh2D_edge'
    mesh2d.edge_face_connectivity = 'Mesh2D_edge_faces'
    mesh2d.edge_node_connectivity = 'Mesh2D_edge_nodes'
    mesh2d.face_coordinates = 'Mesh2D_face_x Mesh2D_face_y'
    mesh2d.face_dimension = 'nMesh2D_face'
    mesh2d.face_edge_connectivity = 'Mesh2D_face_edges'
    mesh2d.face_face_connectivity = 'Mesh2D_face_face'
    mesh2d.face_node_connectivity = 'Mesh2D_face_nodes'
    mesh2d.long_name = "Mesh 2D"
    mesh2d.max_face_nodes_dimension = 'max_nMeshFaceNodes'
    mesh2d.node_coordinates = 'Mesh2D_node_x Mesh2D_node_y'
    mesh2d.node_dimension = 'nMesh2D_node'
    mesh2d.topology_dimension = 2

    mesh2d_x = ncfile.createVariable("Mesh2D_node_x", "f8", ("nMesh2D_node"))
    mesh2d_y = ncfile.createVariable("Mesh2D_node_y", "f8", ("nMesh2D_node"))
    mesh2d_x.standard_name = 'projection_x_coordinate'
    mesh2d_x.units = 'm'
    mesh2d_y.standard_name = 'projection_y_coordinate'
    mesh2d_y.units = 'm'
    mesh2d_x[:] = [-150, 133.043016423945, 581.589811881954, 976.640200542219, 
    1581.56110817825, 2104.17985151006, 2330.51080334667, 2820.20868095679, 
    3326.36699142775, 3836.64041011393, 4091.3328, 4091.0588, 4087.6891, 
    3547.526, 3104.2863, 2530.6819, 2009.2233, 1428.1695, 835.9416, 
    321.93246, -150, -150, 2441.32387428041, 326.036595922787, 
    3368.4335297957, 2852.91575366228, 564.605213864027, 1077.48494483683 ]
   
    mesh2d_y[:] = [625.39432, 908.781962364921, 921.127287010554, 
    464.350275122123, 155.717158981291, 443.774734046067, 600.148846224089, 
    414.968976539589, 530.1920065655, 600.148846224089, 565.79906, 
    99.9999999999999, -350, -350, -350, -350, -350, -350, -350, -350, -350, 
    99.9999999999999, 125.838619350021, 513.501770748115, 134.310966738994, 
    -5.00908866931604, 62.2847173147688, -3.38148493072237 ]

    mesh2d_xu = ncfile.createVariable("Mesh2D_edge_x", "f8", ("nMesh2D_edge"))
    mesh2d_yu = ncfile.createVariable("Mesh2D_edge_y", "f8", ("nMesh2D_edge"))
    mesh2d_xu.standard_name = 'projection_x_coordinate'
    mesh2d_xu.units = 'm'
    mesh2d_yu.standard_name = 'projection_y_coordinate'
    mesh2d_yu.units = 'm'
    mesh2d_xu[:] = [ 3963.98660505697, 3963.84960505697, 4091.1958, 
    2217.34532742836, 2272.75186289524, 2385.91733881354, 2630.7662776186, 
    2575.35974215173, 2056.70157575503, -8.4784917880275, 88.0182979613934, 
    229.539806173366, 3325.90615, 3457.97976489785, 3236.35991489785, 
    2836.56221730954, 4089.37395, 3819.2924, 3817.60755, 357.316414152949, 
    453.81320390237, -150, 85.96623, 85.96623, 2978.60102683114, 
    2691.79882683114, 2817.4841, 2486.00288714021, 3347.40026061173, 
    3073.28783619227, 3094.32110537625, 578.93703, 700.273406932013, 
    443.268836932014, 2269.9526, -150, 88.0182979613934, 207.302606932014, 
    956.713272418414, 651.338398232503, 779.115006212086, 1718.6964, 
    1795.39220408913, 1504.86530408912, 1132.05555, 1252.82722241841, 
    1329.52302650754, 1027.06257268952, 770.622707203123, 1279.10065436023, 
    1842.87047984415, 3602.53696995482, 3581.50370077084 ]
    
    mesh2d_yu[:] = [ 582.973953112045, 350.074423112044, 332.89953, 
    521.961790135078, 284.806676698044, 362.993732787055, 270.403797944805, 
    507.558911381839, 46.8873670230335, 767.088141182461, 569.448045374058, 
    711.141866556518, -350, -107.844516630503, -107.844516630503, 
    204.979943935137, -125, -125, -350, 914.954624687738, 717.314528879334, 
    -125, -350, -125, -177.504544334658, -177.504544334658, -350, 
    -112.080690324989, 332.251486652247, 472.580491552545, 274.639971639292, 
    -350, -143.857641342616, -143.857641342616, -350, 362.69716, 
    306.750885374057, 81.1423586573843, -176.690742465361, 488.926022935119, 
    692.738781066338, -350, -97.1414205093546, -97.1414205093546, -350, 
    -176.690742465361, 76.1678370252842, 230.4843950957, 263.317496218446, 
    310.033717051707, 299.745946513679, 367.229906481542, 565.170426394795]
    

    mesh2d_en = ncfile.createVariable("Mesh2D_edge_nodes", "f8", ("nMesh2D_edge", "Two"))
    mesh2d_en.cf_role = 'edge_node_connectivity'
    mesh2d_en.long_name = 'maps every edge to the two nodes that it connects'
    mesh2d_en.start_index = 1
    mesh2d_en[:, :] = [  11, 10,
  10, 12,
  12, 11,
  7, 6,
  6, 23,
  23, 7,
  23, 8,
  8, 7,
  6, 17,
  2, 1,
  1, 24,
  24, 2,
  15, 14,
  14, 25,
  25, 15,
  26, 8,
  13, 12,
  12, 14,
  14, 13,
  3, 2,
  24, 3,
  22, 21,
  21, 20,
  20, 22,
  26, 15,
  26, 16,
  16, 15,
  23, 16,
  25, 9,
  9, 8,
  8, 25,
  20, 19,
  19, 27,
  27, 20,
  17, 16,
  1, 22,
  22, 24,
  27, 22,
  19, 28,
  24, 4,
  4, 3,
  18, 17,
  17, 5,
  5, 18,
  19, 18,
  18, 28,
  5, 28,
  28, 4,
  4, 27,
  5, 4,
  6, 5,
  25, 10,
  10, 9 ]

    mesh2d_fn = ncfile.createVariable("Mesh2D_face_nodes", "f8", ("nMesh2D_face", "max_nMesh2D_face_nodes"), fill_value=0)
    mesh2d_fn.cf_role = 'face_node_connectivity'
    mesh2d_fn.long_name = 'maps every face to the nodes that it defines'
    mesh2d_fn.start_index = 1
    mesh2d_fn[:, :] = [  1, 22, 24, 0,
  1, 24, 2, 0,
  2, 24, 3, 0,
  3, 24, 4, 0,
  4, 28, 5, 0,
  5, 17, 6, 0,
  5, 28, 18, 0,
  5, 18, 17, 0,
  6, 23, 7, 0,
  7, 23, 8, 0,
  8, 25, 9, 0,
  9, 25, 10, 0,
  10, 12, 11, 0,
  12, 14, 13, 0,
  14, 25, 15, 0,
  15, 26, 16, 0,
  18, 28, 19, 0,
  19, 27, 20, 0,
  20, 27, 22, 0,
  20, 22, 21, 0,
  4, 24, 22, 27,
  4, 27, 19, 28,
  6, 17, 16, 23,
  8, 23, 16, 26,
  8, 26, 15, 25,
  10, 25, 14, 12]

    cm = ncfile.createVariable("composite_mesh", "u4", ())
    cm.cf_role = 'mesh_topology_parent'
    cm.meshes= 'mesh1D mesh2D'
    cm.mesh_contact = 'link1d2d'

    link1d2d = ncfile.createVariable("link1d2d", "u4", ("nlinks_1d2d", "Two"))
    link1d2d.cf_role = 'mesh_topology_contact'
    link1d2d.contact= 'mesh1D:node mesh2D:face'
    link1d2d.start_index = 1
    link1d2d[:,:] = [1, 2,
                     2, 3,
                     3, 4,
                     4, 5,
                     5, 6,
                     6, 9,
                     10, 10,
                     11, 11,
                     12, 12,
                     13, 13]

    # data on the 1D mesh
    
    times = ncfile.createVariable("time", "f8", "time")
    times.standard_time = 'time'
    times.units = 'seconds since 2017-01-01 00:00:00'
    times[0] = 60.0
    times[1] = 120.0

    wl = ncfile.createVariable("s1_1d", "f8", ("time", "nMesh1DNodes"))
    wl.location = 'node'
    wl.long_name = 'water level'
    wl.mesh = 'mesh1D'
    wl.standard_name = 'sea_surface_height_above_geoid'
    wl.units = 'm'
    wl[0, :] = np.linspace(1., 5., nodes_1d)
    wl[1, :] = np.linspace(3., 7., nodes_1d)

    vel = ncfile.createVariable("u_1d", "f8", ("time", "nMesh1DEdges"))
    vel.location = 'edge'
    vel.long_name = 'velocity along branch'
    vel.mesh = 'mesh1D'
    vel.standard_name = 'sea_water_speed'
    vel.units = 'm s-1'
    vel[0, :] = np.linspace(1., 5., edges_1d)
    vel[1, :] = np.linspace(3., 7., edges_1d)

    wl_2d = ncfile.createVariable("s1_2d", "f8", ("time", "nMesh2D_face"))
    wl_2d.coordinates = 'Mesh2D_face_x Mesh2D_face_y'
    wl_2d.location = 'face'
    wl_2d.long_name = 'water level'
    wl_2d.mesh = 'Mesh2D'
    wl_2d.standard_name = 'sea_surface_height_above_geoid'
    wl_2d.units = 'm'
    wl_2d[0, :] = np.linspace(2., 6., faces_2d)
    wl_2d[1, :] = np.linspace(4., 8., faces_2d)

    vel_2d = ncfile.createVariable("u_2d", "f8", ("time", "nMesh2D_edge"))
    vel_2d.coordinates = 'Mesh2D_edge_x Mesh2D_edge_y'
    vel_2d.location = 'edge'
    vel_2d.long_name = 'normal velocity at edge'
    vel_2d.mesh = 'Mesh2D'
    vel_2d.standard_name = 'sea_water_speed'
    vel_2d.units = 'm s-1'
    vel_2d[0, :] = np.linspace(2., 6., edges_2d)
    vel_2d[1, :] = np.linspace(4., 8., edges_2d)


    # global attributes
    ncfile.Conventions = "CF-1.8 UGRID-1.0/Deltares-0.9"
    ncfile.history = "Created on %s D-Flow 1D, D-Flow FM. lD2D coupling" % datetime.now()
    ncfile.institution = "Deltares"
    ncfile.reference = "http://www.deltares.nl"
    ncfile.source = "Python program to test layout of a D-Flow 1D, D-Flow FM"

    return ncfile


if __name__ == "__main__":
    # main(nc_root, var_name)

    start_time = datetime.now()
    print 'Start: %s\n' % start_time

    print 'Create netCDF file for D-Flow 1D, D-Flow FM. lD2D coupling'
    nc_file = netCDF4.Dataset("ugrid_1d2d_map.nc", "w", format="NETCDF4")
    print nc_file.data_model

    main(nc_file)
    print nc_file.Conventions
    nc_file.close()

    print '\nStart: %s' % start_time
    print 'End  : %s' % datetime.now()
    print 'Finished'
